# src/magnifier_core.py

from typing import Any, Optional

import cv2
import numpy as np


class MagnifierCore:
    """
    Core magnifier logic.

    Responsibilities:
    - Maintain zoom state (current zoom, min/max, step)
    - Apply centre-based crop according to zoom
    - Resize cropped region back to original resolution

    This class is intentionally stateless with respect to the camera.
    It only operates on frames (numpy arrays).
    """

    def __init__(
        self,
        zoom: float = 1.0,
        min_zoom: float = 1.0,
        max_zoom: float = 5.0,
        step: float = 0.5,
    ) -> None:
        self.min_zoom = min_zoom
        self.max_zoom = max_zoom
        self.step = step
        self.zoom = self._clamp_zoom(zoom)

    def _clamp_zoom(self, value: float) -> float:
        """Clamp zoom between min_zoom and max_zoom."""
        return max(self.min_zoom, min(self.max_zoom, value))

    # --- Zoom controls -----------------------------------------------------

    def increase_zoom(self) -> None:
        """Increase zoom by one step."""
        self.zoom = self._clamp_zoom(self.zoom + self.step)

    def decrease_zoom(self) -> None:
        """Decrease zoom by one step."""
        self.zoom = self._clamp_zoom(self.zoom - self.step)

    def set_zoom(self, zoom: float) -> None:
        """Set zoom to a specific value, clamped within valid range."""
        self.zoom = self._clamp_zoom(zoom)

    # --- Frame processing --------------------------------------------------

    def process_frame(self, frame: Any) -> Optional[np.ndarray]:
        """
        Apply magnification to the given frame.

        - If frame is None or invalid, returns None.
        - If zoom <= 1.0, returns the original frame unchanged.
        - Otherwise, crops a central region and resizes it back.

        Parameters
        ----------
        frame : Any
            Expected to be a numpy ndarray with shape (H, W, C).

        Returns
        -------
        Optional[np.ndarray]
            Processed frame or None if input is invalid.
        """
        if frame is None:
            return None

        if not isinstance(frame, np.ndarray) or frame.ndim < 2:
            # Unexpected frame format; fail safely.
            return None

        if self.zoom <= 1.0:
            return frame

        h, w = frame.shape[:2]

        # Compute crop size based on zoom factor
        new_w = int(w / self.zoom)
        new_h = int(h / self.zoom)

        # Avoid degenerate cases for extreme zooms
        if new_w <= 0 or new_h <= 0:
            return frame

        x1 = (w - new_w) // 2
        y1 = (h - new_h) // 2
        x2 = x1 + new_w
        y2 = y1 + new_h

        # Safety clamp (in case of rounding issues)
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(w, x2)
        y2 = min(h, y2)

        if x2 <= x1 or y2 <= y1:
            # Something went off; just return original.
            return frame

        cropped = frame[y1:y2, x1:x2]

        # Resize back to original size
        resized = cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)

        return resized
