# src/overlay.py

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np


@dataclass
class OverlayConfig:
    """Configuration options for on-screen overlays."""
    show_zoom: bool = True
    show_fps: bool = True
    show_crosshair: bool = True

    zoom_position: Tuple[int, int] = (10, 30)   # (x, y) in pixels
    fps_position: Tuple[int, int] = (10, 60)    # (x, y) in pixels

    font: int = cv2.FONT_HERSHEY_SIMPLEX
    font_scale: float = 0.6
    font_thickness: int = 1

    text_color: Tuple[int, int, int] = (255, 255, 255)   # white (B, G, R)
    outline_color: Tuple[int, int, int] = (0, 0, 0)      # black

    crosshair_color: Tuple[int, int, int] = (255, 255, 255)
    crosshair_thickness: int = 1
    crosshair_length: int = 20  # length of each arm from centre in pixels


class OverlayRenderer:
    """
    Responsible for drawing overlays on a video frame:
    - Zoom level text
    - FPS text
    - Centre crosshair

    This class does NOT know about camera, input, or business logic.
    It only receives data (zoom, fps) and a frame to draw on.
    """

    def __init__(self, config: Optional[OverlayConfig] = None) -> None:
        self.config = config or OverlayConfig()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def draw(self, frame: np.ndarray, zoom: float, fps: Optional[float]) -> np.ndarray:
        """
        Draw enabled overlays on the given frame and return the annotated frame.

        Parameters
        ----------
        frame : np.ndarray
            The frame to draw on (modified in place).
        zoom : float
            Current zoom factor.
        fps : Optional[float]
            Current frames-per-second estimate (may be None).

        Returns
        -------
        np.ndarray
            The same frame with overlays drawn on it.
        """
        if frame is None or not isinstance(frame, np.ndarray):
            return frame

        if self.config.show_zoom:
            self._draw_zoom_text(frame, zoom)

        if self.config.show_fps:
            self._draw_fps_text(frame, fps)

        if self.config.show_crosshair:
            self._draw_crosshair(frame)

        return frame

    # ------------------------------------------------------------------ #
    # Internal drawing helpers
    # ------------------------------------------------------------------ #

    def _draw_zoom_text(self, frame: np.ndarray, zoom: float) -> None:
        text = f"Zoom: {zoom:.1f}x"
        self._draw_text_with_outline(
            frame,
            text,
            self.config.zoom_position,
        )

    def _draw_fps_text(self, frame: np.ndarray, fps: Optional[float]) -> None:
        if fps is None or fps <= 0:
            text = "FPS: --"
        else:
            text = f"FPS: {fps:.1f}"

        self._draw_text_with_outline(
            frame,
            text,
            self.config.fps_position,
        )

    def _draw_crosshair(self, frame: np.ndarray) -> None:
        h, w = frame.shape[:2]
        cx, cy = w // 2, h // 2

        length = self.config.crosshair_length
        color = self.config.crosshair_color
        thickness = self.config.crosshair_thickness

        # Horizontal line
        cv2.line(
            frame,
            (cx - length, cy),
            (cx + length, cy),
            color,
            thickness,
            lineType=cv2.LINE_AA,
        )

        # Vertical line
        cv2.line(
            frame,
            (cx, cy - length),
            (cx, cy + length),
            color,
            thickness,
            lineType=cv2.LINE_AA,
        )

    def _draw_text_with_outline(
        self,
        frame: np.ndarray,
        text: str,
        position: Tuple[int, int],
    ) -> None:
        """
        Draw text with a simple outline to keep it readable on busy backgrounds.
        """
        x, y = position

        # Outline (draw slightly thicker text in black first)
        cv2.putText(
            frame,
            text,
            (x, y),
            self.config.font,
            self.config.font_scale,
            self.config.outline_color,
            self.config.font_thickness + 2,
            lineType=cv2.LINE_AA,
        )

        # Foreground text
        cv2.putText(
            frame,
            text,
            (x, y),
            self.config.font,
            self.config.font_scale,
            self.config.text_color,
            self.config.font_thickness,
            lineType=cv2.LINE_AA,
        )
