# src/main.py

import time
from typing import Optional

import cv2

from magnifier_core import MagnifierCore
from overlay import OverlayConfig, OverlayRenderer


# ---------------------------------------------------------------------------
# Simple logging helpers
# ---------------------------------------------------------------------------

def log_info(message: str) -> None:
    print(f"[INFO] {message}")


def log_warning(message: str) -> None:
    print(f"[WARN] {message}")


def log_error(message: str) -> None:
    print(f"[ERROR] {message}")


# ---------------------------------------------------------------------------
# Camera helpers
# ---------------------------------------------------------------------------

def open_camera(index: int = 0) -> Optional[cv2.VideoCapture]:
    """
    Try to open a camera by index.
    Returns a cv2.VideoCapture object if successful, otherwise None.
    """
    cap = cv2.VideoCapture(index)

    if not cap.isOpened():
        log_error(f"Cannot open camera at index {index}.")
        cap.release()
        return None

    log_info(f"Camera at index {index} opened successfully.")
    return cap


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------

def main() -> None:
    # Configuration for Phase 1.1
    CAMERA_INDEX = 0
    TARGET_FPS = 30.0  # simple FPS cap to avoid maxing out CPU

    log_info("Starting magnifier (Phase 1.1 - overlays)...")
    log_info(f"Camera index: {CAMERA_INDEX}")
    log_info(f"Target FPS: {TARGET_FPS:.1f}")

    cap = open_camera(CAMERA_INDEX)
    if cap is None:
        # Early exit if camera cannot be opened
        return

    # Magnifier core with zoom bounds and step
    mag = MagnifierCore(zoom=1.0, min_zoom=1.0, max_zoom=5.0, step=0.5)

    # Overlay renderer (zoom + FPS + crosshair)
    overlay_config = OverlayConfig(
        show_zoom=True,
        show_fps=True,
        show_crosshair=True,
    )
    overlay = OverlayRenderer(config=overlay_config)

    window_name = "Magnifier - Phase 1.1"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    #cv2.resizeWindow(window_name, 1280, 720)

    log_info("Controls:")
    log_info("  q  -> quit")
    log_info("  +  -> zoom in")
    log_info("  -  -> zoom out")

    consecutive_failures = 0
    max_failures = 10  # stop if we fail to grab frame too many times

    # FPS tracking
    fps_current: Optional[float] = None
    fps_frame_count = 0
    fps_window_start = time.time()
    fps_update_interval = 1.0  # seconds

    try:
        while True:
            loop_start = time.time()

            ret, frame = cap.read()
            if not ret or frame is None:
                consecutive_failures += 1
                log_warning(
                    f"Failed to grab frame (consecutive failures: {consecutive_failures})"
                )
                if consecutive_failures >= max_failures:
                    log_error("Too many frame grab failures. Exiting.")
                    break
                # Try again next loop iteration
                continue

            # Reset failure counter on success
            consecutive_failures = 0

            # Process frame through the magnifier core
            processed = mag.process_frame(frame)
            if processed is None:
                log_warning("Received invalid frame from magnifier core; showing raw frame.")
                processed = frame

            # Update FPS estimate
            now = time.time()
            fps_frame_count += 1
            elapsed = now - fps_window_start
            if elapsed >= fps_update_interval:
                fps_current = fps_frame_count / elapsed
                fps_frame_count = 0
                fps_window_start = now

            # Draw overlays on the frame
            processed = overlay.draw(processed, zoom=mag.zoom, fps=fps_current)

            cv2.imshow(window_name, processed)

            # Handle key input
            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                log_info("Quit requested by user.")
                break
            elif key == ord("+") or key == ord("="):
                mag.increase_zoom()
                log_info(f"Zoom increased to {mag.zoom:.1f}x")
            elif key == ord("-") or key == ord("_"):
                mag.decrease_zoom()
                log_info(f"Zoom decreased to {mag.zoom:.1f}x")
            else:
                # no relevant key pressed
                pass

            # Simple FPS cap using sleep (not super precise but good enough)
            if TARGET_FPS > 0:
                loop_duration = time.time() - loop_start
                target_frame_time = 1.0 / TARGET_FPS
                sleep_time = target_frame_time - loop_duration
                if sleep_time > 0:
                    time.sleep(sleep_time)

    finally:
        # Always release resources even if there is an exception
        log_info("Releasing camera and closing windows.")
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
