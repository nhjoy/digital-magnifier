from digital_magnifier.core.app_controller import MagnifierApp


def main() -> None:
    app = MagnifierApp()
    app.run()


if __name__ == "__main__":
    main()