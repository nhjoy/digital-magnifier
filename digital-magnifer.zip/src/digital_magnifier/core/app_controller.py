import time
import cv2

from digital_magnifier.core.events import AppEvent
from digital_magnifier.hal.camera_sensor import MockCamera
from digital_magnifier.processing.magnifier import apply_zoom
from digital_magnifier.processing.vision_filters import apply_filter
from digital_magnifier.ui.overlay import draw_overlay
from digital_magnifier.utils.config_loader import load_yaml


class MagnifierApp:
    def __init__(self):
        self.app_config = load_yaml("config/app_config.yaml")
        self.camera_config = load_yaml("config/camera_config.yaml")

        camera_settings = self.camera_config["camera"]

        self.camera = MockCamera(
            width=camera_settings["width"],
            height=camera_settings["height"],
            device_index=camera_settings["device_index"],
        )

        magnifier_settings = self.app_config["magnifier"]
        filter_settings = self.app_config["filters"]

        self.zoom = magnifier_settings["default_zoom"]
        self.min_zoom = magnifier_settings["min_zoom"]
        self.max_zoom = magnifier_settings["max_zoom"]
        self.zoom_step = magnifier_settings["zoom_step"]

        self.pan_x = 0.0
        self.pan_y = 0.0
        self.pan_step = 0.1

        self.filters = filter_settings["available"]
        self.filter_index = self.filters.index(filter_settings["default"])

        self.frozen = False
        self.frozen_frame = None

        self.target_fps = self.app_config["app"]["target_fps"]
        self.frame_delay = 1.0 / self.target_fps

    def run(self) -> None:
        self.camera.start()

        previous_time = time.perf_counter()
        running = True

        while running:
            loop_start = time.perf_counter()

            if not self.frozen:
                frame = self.camera.get_frame()
                self.frozen_frame = frame.copy()
            else:
                frame = self.frozen_frame.copy()

            frame = apply_zoom(frame, self.zoom, self.pan_x, self.pan_y)

            current_filter = self.filters[self.filter_index]
            frame = apply_filter(frame, current_filter)

            now = time.perf_counter()
            fps = 1.0 / max(now - previous_time, 1e-6)
            previous_time = now

            frame = draw_overlay(
                frame=frame,
                zoom=self.zoom,
                filter_name=current_filter,
                frozen=self.frozen,
                fps=fps,
            )

            cv2.imshow("Digital Magnifier Mock", frame)

            event = self._read_keyboard_event()
            running = self._handle_event(event)

            elapsed = time.perf_counter() - loop_start
            sleep_time = max(0.0, self.frame_delay - elapsed)

            if sleep_time > 0:
                time.sleep(sleep_time)

        self.camera.stop()
        cv2.destroyAllWindows()

    def _read_keyboard_event(self) -> AppEvent:
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            return AppEvent.QUIT
        if key in [ord("+"), ord("=")]:
            return AppEvent.ZOOM_IN
        if key in [ord("-"), ord("_")]:
            return AppEvent.ZOOM_OUT
        if key == ord("w"):
            return AppEvent.PAN_UP
        if key == ord("s"):
            return AppEvent.PAN_DOWN
        if key == ord("a"):
            return AppEvent.PAN_LEFT
        if key == ord("d"):
            return AppEvent.PAN_RIGHT
        if key == ord(" "):
            return AppEvent.FREEZE_TOGGLE
        if key == ord("f"):
            return AppEvent.FILTER_NEXT

        return AppEvent.NONE

    def _handle_event(self, event: AppEvent) -> bool:
        if event == AppEvent.QUIT:
            return False

        if event == AppEvent.ZOOM_IN:
            self.zoom = min(self.max_zoom, self.zoom + self.zoom_step)

        elif event == AppEvent.ZOOM_OUT:
            self.zoom = max(self.min_zoom, self.zoom - self.zoom_step)

        elif event == AppEvent.PAN_UP:
            self.pan_y = max(-1.0, self.pan_y - self.pan_step)

        elif event == AppEvent.PAN_DOWN:
            self.pan_y = min(1.0, self.pan_y + self.pan_step)

        elif event == AppEvent.PAN_LEFT:
            self.pan_x = max(-1.0, self.pan_x - self.pan_step)

        elif event == AppEvent.PAN_RIGHT:
            self.pan_x = min(1.0, self.pan_x + self.pan_step)

        elif event == AppEvent.FREEZE_TOGGLE:
            self.frozen = not self.frozen

        elif event == AppEvent.FILTER_NEXT:
            self.filter_index = (self.filter_index + 1) % len(self.filters)

        return True