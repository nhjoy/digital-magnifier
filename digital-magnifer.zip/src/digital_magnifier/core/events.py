from enum import Enum, auto


class AppEvent(Enum):
    NONE = auto()
    ZOOM_IN = auto()
    ZOOM_OUT = auto()
    PAN_UP = auto()
    PAN_DOWN = auto()
    PAN_LEFT = auto()
    PAN_RIGHT = auto()
    FREEZE_TOGGLE = auto()
    FILTER_NEXT = auto()
    CAPTURE_IMAGE = auto()
    QUIT = auto()