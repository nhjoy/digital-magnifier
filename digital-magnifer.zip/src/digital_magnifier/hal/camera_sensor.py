import cv2
import numpy as np


class MockCamera:
    def __init__(self, width: int = 1280, height: int = 720, device_index: int = 0):
        self.width = width
        self.height = height
        self.device_index = device_index
        self.capture = None
        self.use_generated_frame = False

    def start(self) -> None:
        self.capture = cv2.VideoCapture(self.device_index)

        if not self.capture.isOpened():
            self.use_generated_frame = True
            return

        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)

    def get_frame(self):
        if self.use_generated_frame:
            return self._generate_test_frame()

        success, frame = self.capture.read()

        if not success:
            return self._generate_test_frame()

        return frame

    def stop(self) -> None:
        if self.capture is not None:
            self.capture.release()

    def _generate_test_frame(self):
        frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)

        cv2.putText(
            frame,
            "DIGITAL MAGNIFIER MOCK FRAME",
            (80, 180),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.5,
            (255, 255, 255),
            3,
            cv2.LINE_AA,
        )

        cv2.putText(
            frame,
            "Small text reading test: abcdefghijklmnopqrstuvwxyz 1234567890",
            (80, 300),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (220, 220, 220),
            2,
            cv2.LINE_AA,
        )

        cv2.putText(
            frame,
            "Use + / - for zoom, WASD for pan, F for filter, SPACE to freeze, Q to quit",
            (80, 420),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (180, 180, 180),
            2,
            cv2.LINE_AA,
        )

        return frame