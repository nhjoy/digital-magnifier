import cv2
import numpy as np


def apply_zoom(
    frame: np.ndarray,
    zoom: float,
    pan_x: float = 0.0,
    pan_y: float = 0.0,
) -> np.ndarray:
    if zoom <= 1.0:
        return frame

    height, width = frame.shape[:2]

    crop_width = int(width / zoom)
    crop_height = int(height / zoom)

    center_x = width // 2 + int(pan_x * (width - crop_width) / 2)
    center_y = height // 2 + int(pan_y * (height - crop_height) / 2)

    x1 = max(0, min(width - crop_width, center_x - crop_width // 2))
    y1 = max(0, min(height - crop_height, center_y - crop_height // 2))

    cropped = frame[y1:y1 + crop_height, x1:x1 + crop_width]

    return cv2.resize(cropped, (width, height), interpolation=cv2.INTER_LINEAR)