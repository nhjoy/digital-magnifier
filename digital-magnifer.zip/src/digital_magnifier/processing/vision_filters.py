import cv2
import numpy as np


def apply_filter(frame: np.ndarray, filter_name: str) -> np.ndarray:
    if filter_name == "normal":
        return frame

    if filter_name == "grayscale":
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

    if filter_name == "high_contrast":
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        enhanced = cv2.equalizeHist(gray)
        return cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)

    if filter_name == "inverted":
        return cv2.bitwise_not(frame)

    return frame