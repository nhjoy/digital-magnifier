# Digital Magnifier

A small, experimental digital magnifier built with Python and OpenCV.  
The long-term goal is to create a **low-cost, portable magnifier** for people with low vision, running on a Raspberry Pi with a camera and a simple screen.

> **Current status:** Phase 0 – desktop prototype running on Ubuntu 24.04, with live camera preview and basic zoom controls.

---

## Project Goals

- Provide a **budget-friendly alternative** to commercial digital magnifiers.
- Focus on **clarity and practicality** over fancy UI.
- Design the software so it is:
  - Portable (desktop → Raspberry Pi)
  - Easy to understand and extend
  - Eventually suitable for real users (children with low vision, low-income families, etc.)

---

## Tech Stack

- **Language:** Python 3
- **Core library:** OpenCV (`opencv-python`)
- **Target dev environment:** Ubuntu 24.04 (desktop)
- **Planned deployment:** Raspberry Pi 5 (64-bit), later with Docker

---

## Current Features (Phase 0)

- Opens the default camera and shows a **live video feed**.
- Simple **centre-based zoom** using a `MagnifierCore` class:
  - Crops the centre of the image according to the zoom level.
  - Resizes the cropped region back to full frame size.
- **Keyboard controls** for zoom in/out and quitting.
- Basic **robustness features**:
  - Handles camera open failure gracefully.
  - Handles repeated frame grab failures and exits cleanly.
  - Simple FPS cap to avoid maxing out the CPU.
  - Always releases the camera and closes windows on exit.

---

## Getting Started

### 1. Clone the repository

```bash
git clone git@github.com:nhjoy/digital-magnifier.git
cd digital-magnifier
